# Erros comuns em diagramas de sequência UML

Trabalho de Engenharia de Software (PRES_80_200) — Tema 5, 2026/2, 2º bimestre.

**Integrantes:** Pedro Gabriel Bueno Valgas e Caio Miguel Martins Carmona Pereira

**Cenário:** checkout de uma loja virtual.

Cinco erros típicos em diagramas de sequência, cada um com o diagrama incorreto e o corrigido:

1. Fluxo incoerente (persistir antes de validar)
2. Ator ligado diretamente ao banco de dados
3. Retorno relevante omitido
4. Fragmento `alt` sem condições de guarda
5. Barras de ativação incoerentes

## Conteúdo

| Arquivo | Descrição |
|---|---|
| `trabalho_escrito.docx` / `trabalho_escrito.pdf` | Trabalho escrito |
| `apresentacao.pptx` | Slides da apresentação |
| `diagramas/*.puml` | Código-fonte PlantUML dos diagramas |
| `diagramas/exportados/*.png` | Diagramas exportados em imagem |
